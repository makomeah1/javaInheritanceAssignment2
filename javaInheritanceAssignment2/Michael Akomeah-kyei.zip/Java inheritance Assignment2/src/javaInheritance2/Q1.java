package javaInheritance2;

public class Q1 {
	

	public static void main(String[] args) {
		Author poly = new Author("James", "legato@gmail.com", 'M');
        //Book(String name,double price,int qty,Author author) 
        Book book = new Book("The lovers Rock", 22.43,5,poly);
        System.out.println(book);
	}

}

class Author{
	
	private String name;
	private String email;
	private char gender;
	
	Author(String name,String email,char gender){
		this.name= name;
		this.email=email;
		this.gender=gender;
	}
	
	public String getName() {
		return name;	

	}
	public String getEmail() {
		return email;
		
	}
	
	public char getGender() {
		return gender;
		
	}
	 public  String toString() {
		   return name + " "+"("+gender+")"+ " at "+ email;
	   }
		
	
}





class Book{
	
private String name;
private double price;
private int qty;
Author author;

public Book(String name,double price,int qty,Author author) {
	this.name = name;
	this.price= price;
	this.qty =qty;
	this.author=author;	
	
}

public String getName() {	
	return name;
}
	
public Author getAuthor() {
	return author;
	
}
	
	public double price(){
		return price;
		
	}
	public double setprice(double price) {
		return this.price =price;
	}
	
	public int getQty() {
		return qty;
	}
	
	public int setQty(int qty) {
		return this.qty=qty;
	}
	
	
public String toString() {
	return "'"+getName()+"'" + " "   + author.toString();
}
	
	
	
	
}















